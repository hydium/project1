/* Creates a directory,
   then creates 50 files in that directory. */

#define FILE_CNT 50
#define DIRECTORY "/x"
#include "tests/filesys/extended/grow-dir.inc"
